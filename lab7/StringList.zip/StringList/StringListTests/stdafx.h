// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


#include <stdio.h>

#define BOOST_TEST_INCLUDED

#define BOOST_TEST_NO_MAIN
#pragma warning (disable:4702)

#include <boost/test/unit_test.hpp>
#include <boost/algorithm/string/replace.hpp>

// TODO: reference additional headers your program requires here
