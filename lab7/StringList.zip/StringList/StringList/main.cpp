#include <iostream>
#include <list>
#include "StringList.h"
#include "StringListIterator.h"
using namespace std;

int main()
{
    return 0;
}